House sound effects
===================

sfx/ holds the effects the pipeline's cue sheets place, renamed by their job. They come from a free editing SFX
pack shared on Google Drive (not paid), except click.wav and phone_ring.wav, which were made in code. Some files
are trimmed so the sound is loud from its first frame, and some carry a gain so every job sits at its level.

manifest.json lists every effect with its job, its level against the voice (cue-sheet dB), how to place it, and
how often finished long videos and Shorts used it (most, often, sometimes: a guide to what gets used,
not a quota).
The creator's own effects go next to these in the effects folder; their taste replaces these picks.
